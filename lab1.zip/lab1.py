import nltk
import sys

# Import the Presidential inaugural speeches corpus
from nltk.corpus import inaugural


#################### EXERCISE 1 ####################

# Solution for exercise 1
# Input: doc_name (string)
# Output: total_words (int), total_distinct_words (int)
def ex1(doc_name):
    # Use the plaintext corpus reader to access a pre-tokenised list of words
    # for the document specified in "doc_name"
    doc_words = inaugural.words(doc_name)

    # Find the total number of words in the speech
    #total_words = 

    # Find the total number of DISTINCT words in the speech
    #total_distinct_words = 

    # Return the sentence and word counts
    return total_words, total_distinct_words


### Uncomment to test exercise 1
#speech_name = '2009-Obama.txt'
#tokens, types = ex1(speech_name)
#print("Total words in %s: %d" % (speech_name,  tokens))
#print("Total distinct words in %s: %d" % (speech_name, types))


#################### EXERCISE 2 ####################

# Solution for exercise 2
# Input: doc_name (string)
# Output: total_sent (int), avg_sent_length (float)
def ex2(doc_name):
    # Use the plaintext corpus reader to access the pre-tokenised list of sentences
    # for the document specified in "doc_name"
    doc_sents = inaugural.sents(doc_name)

    # Find the total number of sentences in the speech
    #total_sents = 

    # Find the average sentence length
    #avg_sent_length = 

    # Return the total number of sentences and the average sentence length of the document
    return total_sents, avg_sent_length


### Uncomment to test exercise 2 
#speech_name = '2009-Obama.txt'
#sents, avg_sent_len = ex2(speech_name)
#print("Total sentences in %s: %d" % (speech_name,  sents))
#print("Average sentence length for %s: %.2f" % (speech_name, avg_sent_len))



#################### EXERCISE 3 ####################

# Solution for exercise 3
# Input: doc_name (string)
# Output: avg_word_length (float)
def ex3(doc_name):
    doc_words = inaugural.words(doc_name)

    # Construct a list that contains the word lengths for each DISTINCT word in the document
    #distinct_word_lengths = 

    # Find the average word length
    #avg_word_length = 

    # Return the average word length of the document
    return avg_word_length


### Uncomment to test exercise 3 
speech_name = '2009-Obama.txt'
#result2 = ex3(speech_name)
#print("Average word length for %s: %.2f" % (speech_name, result2))


#################### EXERCISE 4 ####################

# Solution for exercise 4
# Input: doc_name (string), x (int)
# Output: top_words (list)
def ex4(doc_name, x):
    doc_words = inaugural.words(doc_name)
    
    # Construct a frequency distribution over the lowercased words in the document
    #fd_doc_words = 

    # Find the top x most frequently used words in the document
    #top_words = 

    # Return the top x most frequently used words
    return top_words


### Uncomment to test exercise 4
#print("Top 50 words for Obama's 2009 speech:")
#result4a = ex4('2009-Obama.txt', 50)
#print(result4a)
#print("Top 50 words for Washington's 1789 speech:")
#result4b = ex4('1789-Washington.txt', 50)
#print(result4b)


#################### EXERCISE 5 ####################

# Solution for exercise 5
# Input: doc_name (string), th (int)
# Output: number of words exceeding a frequency threshold (int)
def ex5(doc_name, th):
    doc_words = inaugural.words(doc_name)
    
    # Construct a frequency distribution over the lowercased words in the document
    #fd_doc_words = 

    # Keep only those words that occur at least x times
    #freq_words = 

    # Find the number of filtered words
    #num_freq_words = 

    # Return the number of words occurring at least th times
    return num_freq_words


### Uncomment to test exercise 5
#speech_name = '2009-Obama.txt'
#for th in (3, 5, 10):
#    res = ex5('2009-Obama.txt', th)
#    print("The number of words in %s occurring more than %d times: %d" % (speech_name, th, res))


#################### EXERCISE 6 ####################

# Solution for exercise 6
# Input: doc_name (string)
# Output: number of hapax legomena (int)
def ex6(doc_name):
    doc_words = inaugural.words(doc_name)
    
    # Construct a frequency distribution over the lowercased words in the document
    fd_doc_words = nltk.FreqDist(w.lower() for w in doc_words)

    # Find the word that occur only once
    #hapax_words = 

    # Find the number of words that occur only once
    #num_hapax_words = 

    # Return the number of words that occur only once
    return num_hapax_words


### Uncomment to test exercise 6
#speech_name = '2009-Obama.txt'
#res = ex6('2009-Obama.txt')
#print("The number of hapaxes in %s: %d" % (speech_name, res))


#################### EXERCISE 7 ####################

# Solution for exercise 7
# Input: doc_name (string), x (int), stemmer (string)
# Output: top_stems (list)
def ex7(doc_name, x, stemmer):
    doc_words = inaugural.words(doc_name)

    # Construct the stemmer
    #if stemmer == "porter":
    #    stemmer_ = 
    #elif stemmer == "lancaster":
    #    stemmer_ = 
    #elif stemmer == "snowball":
    #    stemmer_ = 
    #else:
    #    raise ValueError("Unknown stemmer: %s" % stemmer)

    # stem the lowercased text
    #stemmed_words = 
    
    # Construct a frequency distribution over the stemmed words in the document
    #fd_doc_stems = 

    # Find the top x stems
    #top_stems = 

    # Return the top stems
    return top_stems


### Uncomment to test exercise 7
#speech_name = '2009-Obama.txt'
#for st in ("porter", "lancaster", "snowball"):
#    res = ex7('2009-Obama.txt', 50, st)
#    print("Top 50 stems with %s stemmer:" % st)
#    print(res)


#################### EXERCISE 8 ####################

# Solution for exercise 8
# Input: doc_name (string)
# Output: words_without_stop (int), types_without_stop (int)
def ex8(doc_name):
    doc_words = inaugural.words(doc_name)
    
    distinct_words = list(set(doc_words))

    # Get the stopwords
    #stop_words = 

    # Find the words with stopwords filtered out
    #filtered_words = 

    # Find the number of words with stopwords filtered out
    #words_without_stop = 

    # Find the number of distinct word types without stopwords
    #types_without_stop = 
    
    # Return the number of word tokens and word types without stopwords
    return words_without_stop, types_without_stop


### Uncomment to test exercise 8
#speech_name = '2009-Obama.txt'
#tokens_without_stop, types_without_stop = ex8('2009-Obama.txt')
#print("The number of word tokens after removing stop words: %d" % tokens_without_stop)
#print("The number of word types after removing stop words: %d" % types_without_stop)


#################### EXERCISE 9 ####################

# Solution for exercise 9
# Input: doc_name (string)
# Output: pos_freq_dist
def ex9(doc_name):
    doc_sents = inaugural.sents(doc_name)
    
    # POS tag the tokenized text
    #tagged_text = 

    # Extract only POS tags
    #tags = 

    # Compute frequency distribution over the POS tags
    # pos_freq_dist = 

    # Return the frequency distribution over the POS tags
    return pos_freq_dist


### Uncomment to test exercise 9
#speech_name = '2009-Obama.txt'
#res = ex9('2009-Obama.txt')
#print("The POS tag frequency distribution:")
#print(res.tabulate())


#################### EXERCISE 10  ####################

def convert_tag(tag):
    # Converts POS tags to the POS labels required by the WordNet lemmatizer
    # N* --> n
    # V* --> v
    # A* --> a
    # R* --> r
    # Input: tag (string)
    # Output: label (character)

    # The default label is 'n'
    label = 'n'
    # If the tag is a verb and starts with V
    #if tag.startswith('V'):
    #    label = 
    
    # If the tag is an adjective and starts with A
    #elif
    #    label = 
    
    # If the tag is an adverb and starts with R
    #elif 
    #    label = 
    
    # Return the label
    return label

# Solution for exercise 10
# Input: doc_name (string), x (int)
# Output: top_lemmas (list)

def ex10(doc_name, x):
    doc_sents = inaugural.sents(doc_name)
    
    # POS tag the tokenized text
    #tagged_text = 

    # Construct a WordNet lemmatizer
    #lemmatizer = 

    # Lemmatize text
    #lemmas = 

    # Compute frequency distribution over the lemmas
    #lemma_freq_dist = 

    # Find the x most frequent lemmas
    #top_lemmas = 

    # Return the top most frequent lemmas
    return top_lemmas


### Uncomment to test exercise 10
#speech_name = '2009-Obama.txt'
#res = ex10('2009-Obama.txt', 50)
#print("The top 50 most frequent lemmas:")
#print(res)


#################### EXERCISE 11 ####################

# Solution for exercise 11
# Input: root (string), filename (string)
# Output: num_sents (int), num_words (int)
def ex11(root, filename):
    # Use the plain text corpus reader to construct the corpus handler
    #corpus_handle = nltk.corpus.PlaintextCorpusReader(root, filename)
    
    # Split the text into sentences
    #sents = 

    # Tokenize text into words
    #words = 

    # Find the number of sentences
    #num_sents = 

    # Find the number of words
    #num_words = 

    # Return the number of sentences and the number of words
    return num_sents, num_words


### Uncomment to test exercise 11
# The path to directory containing the file
#root = 
#filename = 'random_wiki_article.txt'
#num_sents, num_words = ex11(root, filename)
#print("The number of sentences in %s: %d" % (filename, num_sents))
#print("The number of words in %s: %d" % (filename, num_words))

